from django.urls import path
from . import views

app_name = 'myapp'

urlpatterns = [
    # API endpoint for form submission (JSON/AJAX requests)
    path('api/submit-contact/', views.submit_contact_form, name='submit_contact_api'),
    
    # Combined view for displaying form and handling submissions
    path('contact/', views.contact_form_view, name='contact_form'),
]