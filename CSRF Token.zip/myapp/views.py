from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
import json
import logging
from .models import ContactSubmission

logger = logging.getLogger(__name__)

@csrf_exempt
@require_http_methods(["POST"])
def submit_contact_form(request):
    """
    Handle contact form submission without CSRF token validation.
    Accepts POST request with JSON or form data and saves to database.
    """
    try:
        # Parse request data
        if request.content_type == 'application/json':
            data = json.loads(request.body)
        else:
            data = request.POST
        
        # Extract and validate required fields
        name = data.get('name', '').strip()
        email = data.get('email', '').strip()
        message = data.get('message', '').strip()
        
        # Validation
        errors = []
        
        if not name:
            errors.append("Name is required")
        elif len(name) > 100:
            errors.append("Name must be less than 100 characters")
            
        if not email:
            errors.append("Email is required")
        else:
            try:
                validate_email(email)
            except ValidationError:
                errors.append("Please enter a valid email address")
                
        if not message:
            errors.append("Message is required")
        elif len(message) > 1000:
            errors.append("Message must be less than 1000 characters")
        
        if errors:
            return JsonResponse({
                'success': False,
                'errors': errors
            }, status=400)
        
        # Save to database
        contact_submission = ContactSubmission.objects.create(
            name=name,
            email=email,
            message=message
        )
        
        logger.info(f"New contact submission saved: ID {contact_submission.id}")
        
        return JsonResponse({
            'success': True,
            'message': 'Contact form submitted successfully',
            'submission_id': contact_submission.id
        }, status=201)
        
    except json.JSONDecodeError:
        return JsonResponse({
            'success': False,
            'errors': ['Invalid JSON data']
        }, status=400)
        
    except Exception as e:
        logger.error(f"Error processing contact form: {str(e)}")
        return JsonResponse({
            'success': False,
            'errors': ['An unexpected error occurred. Please try again.']
        }, status=500)


@csrf_exempt 
def contact_form_view(request):
    """
    Display contact form and handle form submissions.
    GET: Display HTML form
    POST: Process form submission
    """
    if request.method == 'GET':
        html_form = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Contact Form</title>
            <style>
                body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
                .form-group { margin-bottom: 15px; }
                label { display: block; margin-bottom: 5px; font-weight: bold; }
                input, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
                button { background-color: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
                button:hover { background-color: #005a87; }
                .error { color: red; margin-top: 10px; }
                .success { color: green; margin-top: 10px; }
            </style>
        </head>
        <body>
            <h1>Contact Us</h1>
            <form id="contactForm" method="post">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="message">Message:</label>
                    <textarea id="message" name="message" rows="5" required></textarea>
                </div>
                
                <button type="submit">Send Message</button>
            </form>
            
            <div id="result"></div>
            
            <script>
                document.getElementById('contactForm').addEventListener('submit', async function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const resultDiv = document.getElementById('result');
                    
                    try {
                        const response = await fetch('/api/submit-contact/', {
                            method: 'POST',
                            body: formData
                        });
                        
                        const data = await response.json();
                        
                        if (data.success) {
                            resultDiv.innerHTML = `<div class="success">${data.message}</div>`;
                            this.reset();
                        } else {
                            resultDiv.innerHTML = `<div class="error">Errors: ${data.errors.join(', ')}</div>`;
                        }
                    } catch (error) {
                        resultDiv.innerHTML = `<div class="error">Network error. Please try again.</div>`;
                    }
                });
            </script>
        </body>
        </html>
        """
        return HttpResponse(html_form)
    
    elif request.method == 'POST':
        return submit_contact_form(request)