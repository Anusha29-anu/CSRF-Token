#!/usr/bin/env python
"""
Test script for the Django CSRF exempt API endpoint.
Run this after starting the Django server to test the functionality.
"""

import json
import urllib.request
import urllib.parse

def test_json_request():
    """Test the API with JSON data"""
    url = 'http://localhost:8000/api/submit-contact/'
    data = {
        'name': 'John Doe',
        'email': 'john.doe@example.com',
        'message': 'This is a test message from the JSON API test.'
    }
    
    json_data = json.dumps(data).encode('utf-8')
    
    req = urllib.request.Request(
        url,
        data=json_data,
        headers={'Content-Type': 'application/json'}
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            print("JSON Request Test:")
            print(f"Status: {response.status}")
            print(f"Response: {result}")
            print()
    except urllib.error.HTTPError as e:
        error_response = json.loads(e.read().decode('utf-8'))
        print(f"JSON Request Error: {e.code}")
        print(f"Error Response: {error_response}")
        print()

def test_form_request():
    """Test the API with form data"""
    url = 'http://localhost:8000/api/submit-contact/'
    data = {
        'name': 'Jane Smith',
        'email': 'jane.smith@example.com',
        'message': 'This is a test message from the form data API test.'
    }
    
    form_data = urllib.parse.urlencode(data).encode('utf-8')
    
    req = urllib.request.Request(
        url,
        data=form_data,
        headers={'Content-Type': 'application/x-www-form-urlencoded'}
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            print("Form Data Request Test:")
            print(f"Status: {response.status}")
            print(f"Response: {result}")
            print()
    except urllib.error.HTTPError as e:
        error_response = json.loads(e.read().decode('utf-8'))
        print(f"Form Data Request Error: {e.code}")
        print(f"Error Response: {error_response}")
        print()

def test_validation_errors():
    """Test the API with invalid data to check validation"""
    url = 'http://localhost:8000/api/submit-contact/'
    data = {
        'name': '',  # Empty name should cause validation error
        'email': 'invalid-email',  # Invalid email format
        'message': ''  # Empty message should cause validation error
    }
    
    json_data = json.dumps(data).encode('utf-8')
    
    req = urllib.request.Request(
        url,
        data=json_data,
        headers={'Content-Type': 'application/json'}
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            print("Validation Test (should show errors):")
            print(f"Status: {response.status}")
            print(f"Response: {result}")
            print()
    except urllib.error.HTTPError as e:
        error_response = json.loads(e.read().decode('utf-8'))
        print("Validation Test (expected errors):")
        print(f"Status: {e.code}")
        print(f"Error Response: {error_response}")
        print()

if __name__ == '__main__':
    print("Testing Django CSRF Exempt API Endpoint")
    print("=" * 50)
    print("Make sure Django server is running on localhost:8000")
    print("Run: python manage.py runserver")
    print("=" * 50)
    print()
    
    test_json_request()
    test_form_request()
    test_validation_errors()
    
    print("Testing complete!")
    print("Visit http://localhost:8000/contact/ to test the web form interface.")c