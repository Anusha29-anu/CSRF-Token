# Django CSRF Exempt Form Handler

This Django project demonstrates how to create views that accept form data without CSRF token validation using the `@csrf_exempt` decorator.

## Project Structure

- `myapp/models.py` - ContactSubmission model for storing form data
- `myapp/views.py` - Views with CSRF exemption and form handling
- `myapp/urls.py` - URL patterns for the app
- `myproject/urls.py` - Main URL configuration
- `myapp/admin.py` - Admin interface configuration

## Setup Instructions

1. Install Django:
   ```bash
   pip install -r requirements.txt
   ```

2. Create and run migrations:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

3. Create a superuser (optional):
   ```bash
   python manage.py createsuperuser
   ```

4. Run the development server:
   ```bash
   python manage.py runserver
   ```

## Usage

### API Endpoint
- **URL**: `/api/submit-contact/`
- **Method**: POST
- **Content-Type**: `application/json` or `application/x-www-form-urlencoded`
- **Data**: 
  ```json
  {
    "name": "John Doe",
    "email": "john@example.com",
    "message": "Hello, this is a test message."
  }
  ```

### Web Form
- **URL**: `/contact/`
- **Method**: GET (displays form) / POST (handles submission)

## Features

- **CSRF Exemption**: Uses `@csrf_exempt` decorator to bypass CSRF validation
- **Data Validation**: Validates required fields and email format
- **Error Handling**: Comprehensive error handling with proper HTTP status codes
- **JSON/Form Support**: Accepts both JSON and form-encoded data
- **Admin Integration**: View and manage submissions through Django admin
- **Logging**: Logs successful submissions and errors

## Security Considerations

⚠️ **Important**: Disabling CSRF protection removes an important security layer. Only use `@csrf_exempt` when:

1. Building APIs for external consumption
2. Handling webhook requests from third-party services
3. You have alternative security measures in place

Consider implementing:
- API key authentication
- Rate limiting
- Input sanitization
- HTTPS enforcement

## Testing

Test the API endpoint using curl:

```bash
# Test JSON request
curl -X POST http://localhost:8000/api/submit-contact/ \
  -H "Content-Type: application/json" \
  -d '{"name": "Test User", "email": "test@example.com", "message": "Test message"}'

# Test form data request
curl -X POST http://localhost:8000/api/submit-contact/ \
  -d "name=Test User&email=test@example.com&message=Test message"
```

## Model Schema

The `ContactSubmission` model includes:
- `name`: CharField (max 100 characters)
- `email`: EmailField with validation
- `message`: TextField for longer content
- `created_at`: Auto-generated timestamp

All submissions are stored in the database and can be viewed through the Django admin interface.